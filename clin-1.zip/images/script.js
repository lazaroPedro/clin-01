/*console.log('Hello!');

const activeClass = 'active';
const list = document.querySelectorAll('li.navItem');

addEventListener(click, document.i)*



----------


const list = document.querySelectorAll('.navItem')
function activeLink(){
  list.forEach((item) => 
  item.classList.remove('active'))
  this.classList.add('active')
}
list.forEach((item) =>
item.addEventListener('mousemove', activeLink))


------------




/*

$("#homeLink").click(function() {
  $('html, body').animate({
      scrollTop:        $("#home").offset().top-66
  }, 1000);
return false;
});

$("#aboutLink").click(function() {
  $('html, body') .animate({
      scrollTop:        $("#about-us").offset().top-112
  }, 1000);
return false;
});*/
